﻿using DoceCantinho.Application.DTOs;
using DoceCantinho.Infrastructure.Identity;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;


namespace DoceCantinho.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : Controller
    {
        //UserManager e SignManager são serviços do Identity
        //UserManager: gerencia operações com usuários (criar, buscar...)
        //SignManager: gerencia operações de autenticação (login, logout...)
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager;
        private readonly RoleManager<IdentityRole> _roleManager;

        public AuthController(
            UserManager<ApplicationUser> userManager,
            SignInManager<ApplicationUser> signInManager,
            RoleManager<IdentityRole> roleManager)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _roleManager = roleManager;
        }

        /// <summary>
        /// Registra um novo usuário.
        /// POST /api/auth/register
        /// </summary>
        [HttpPost("register")]
        public async Task<ActionResult> Register([FromBody] RegisterDto dto)
        {
            //validação de senha
            if (dto.Password != dto.ConfirmPassword)
                return BadRequest(new { message = "As senhas não coincidem." });

            var user = new ApplicationUser
            {
                UserName = dto.Email,
                Email = dto.Email,
                Cpf = "000.000.000-00",
                Logradouro = string.Empty,
                Bairro = string.Empty,
                Cidade = string.Empty,
                Estado = string.Empty,
                Numero = string.Empty,
                Cep = string.Empty
            };

            //Cria o usuário usando o UserManager
            var result = await _userManager.CreateAsync(user, dto.Password);

            if (!result.Succeeded)
            {
                var errors = result.Errors.Select(erros => erros.Description);
                return BadRequest(new { message = "Erro ao registrar usuário.", errors });
            }

            const string rolePadrao = "Usuário";
            if (!await _roleManager.RoleExistsAsync(rolePadrao))
            {
                await _roleManager.CreateAsync(new IdentityRole(rolePadrao));
            }

            var roleResult = await _userManager.AddToRoleAsync(user, rolePadrao);
            if (!roleResult.Succeeded)
            {
                var roleErrors = roleResult.Errors.Select(e => e.Description);
                return BadRequest(new { message = "Usuário criado, mas não foi possível vincular role padrão.", errors = roleErrors });
            }

            return Ok(new { message = "Usuário registrado com sucesso." });
        }

        ///<summary>
        ///Faz login do usuário.
        ///POST /api/auth/login
        /// </summary>
        [HttpPost("login")]
        public async Task<ActionResult> Login([FromBody] LoginDto dto)
        {
            var result = await _signInManager.PasswordSignInAsync(
                dto.Email, dto.Password, isPersistent: false, lockoutOnFailure: false);
            // isPersistent: se o cookie de autenticação deve ser persistente (permanecer após fechar o navegador)     
            //lockoutOnFailure: se deve bloquear a conta após falhas consecutivas de login
            if (!result.Succeeded)
            {
                return Unauthorized(new { message = "Email ou senha inválidos. " });
            }

            var user = await _userManager.FindByEmailAsync(dto.Email);
            if (user == null)
                return Unauthorized(new { message = "Usuário não encontrado após login." });

            var roles = await _userManager.GetRolesAsync(user);

            return Ok(new UserDto
            {
                Id = user.Id,
                Email = user.Email!,
                Roles = roles
            });
        }

        /// <summary>
        /// Faz logout do usuário
        /// POST /api/auth/logout
        /// </summary>
        [HttpPost("logout")]
        [Authorize]  //autorização
        public async Task<ActionResult> Logout()
        {
            await _signInManager.SignOutAsync();
            return Ok(new { message = "Logout realizado com sucesso!" });
        }


        /// <summary>
        /// Retorna os dados do usuário autenticado
        /// GET /api/auth/me
        /// </summary>
        [HttpGet("me")]
        [Authorize]
        public async Task<ActionResult<UserDto>> Me()
        {
            var user = await _userManager.GetUserAsync(User);

            if (user == null)
                return Unauthorized(new { message = "Usuário não autenticado." });

            var roles = await _userManager.GetRolesAsync(user);

            return Ok(new UserDto
            {
                Id = user.Id,
                Email = user.Email,
                Roles = roles
            });


        }




    }
}
